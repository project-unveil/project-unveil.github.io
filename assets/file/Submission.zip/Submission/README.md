# UNVEIL — BONES-SEED Supplementary Code

**UNVEIL** (Universal Non-intrusive Evaluation via Invariant Latent representations) is the
training and evaluation framework used in the paper.  Three backbone variants are provided
in a single script (`unveil.py`).


## Directory layout

## Dependencies

```
torch >= 2.0
numpy
pandas
scikit-learn
mmcv          # required for proto-mem only
triton        # required for torch.compile (optional; use --no-compile if not available)
```

The `dyn-graph` and `proto-mem` variants require their respective external library
directories (`DS-GCN/` and `ProtoGCN/`) to be present under the project root.
`stream-attn` has no external model dependencies beyond PyTorch.

---

## Quick start

```bash
# Re-ID with stream-attn on G1 data (default variant)
python Submission/unveil.py --variant stream-attn --format g1 --task reid

# Gender classification with dyn-graph on uniform BVH
python Submission/unveil.py --variant dyn-graph --format uniform --task gender

# Age regression with proto-mem on proportional BVH
python Submission/unveil.py --variant proto-mem --format proportional --task age

# Run all privacy tasks with stream-attn
python Submission/unveil.py --variant stream-attn --format g1 --task all

# Quick dry-run (limited data, 1 epoch)
python Submission/unveil.py --variant stream-attn --task reid --max-train 200 --max-test 100 --epochs 1

# Re-ID with dyn-graph using closed-set evaluation
python Submission/unveil.py --variant dyn-graph --format g1 --task reid --reid-eval closed-set

# Re-ID with stream-attn using centroid-based evaluation (default for stream-attn)
python Submission/unveil.py --variant stream-attn --format g1 --task reid --reid-eval centroid
```

---


### Training arguments

| Argument | Default | Description |
|---|---|---|
| `--epochs` | 100 | Number of training epochs |
| `--lr` | variant-specific | Learning rate |
| `--batch-size` | variant-specific | Batch size |
| `--weight-decay` | 1e-4 | AdamW weight decay |
| `--label-smoothing` | 0.05 | Cross-entropy label smoothing |
| `--lambda-supcon` | 0.1 | SupCon loss weight (0 = CE only) |
| `--lambda-proto` | 0.1 | Memory contrastive loss weight (proto-mem only) |
| `--supcon-warmup` | variant-specific | Epoch to start contrastive losses |
| `--supcon-temp` | 0.07 | SupCon temperature |
| `--early-stop` | 40 | Early stopping patience (eval cycles) |
| `--eval-every` | 1 | Evaluate every N epochs |
| `--seed` | 42 | Random seed |

### Architecture arguments

| Argument | Variants | Default | Description |
|---|---|---|---|
| `--emb-dim` | all | 256 | Embedding dimension |
| `--dim1` | stream-attn | 256 | Feature dimension |
| `--seg` | stream-attn | 64 | Temporal segments |
| `--base-channels` | dyn-graph, proto-mem | 64/96 | Base channel count |
| `--num-stages` | dyn-graph, proto-mem | 10 | Number of spatiotemporal blocks |
| `--num-prototype` | proto-mem | 100 | Number of latent prototypes |
| `--dropout` | dyn-graph, proto-mem | 0.5 | Dropout rate |
| `--variance-percentile` | all (BVH) | variant-specific | BVH channel variance filtering (0 = keep all) |

### Evaluation arguments

| Argument | Default | Description |
|---|---|---|
| `--reid-eval` | variant-specific | `centroid` (stream-attn default) or `closed-set` (dyn-graph/proto-mem default) |
| `--split-mode` | `user` | `user` = Phase 2 manifests; `user_task` = regenerate from metadata |
| `--deconfound` | `residual` | Embedding deconfounding: `none` or `residual` |
| `--deconfound-key` | `package` | Metadata column for task deconfounding |

### I/O arguments

| Argument | Default | Description |
|---|---|---|
| `--checkpoint-dir` | auto | Checkpoint base directory |
| `--save-every` | 10 | Save periodic checkpoint every N epochs |
| `--max-train` | 0 | Limit training samples (0 = all) |
| `--max-test` | 0 | Limit test samples (0 = all) |
| `--num-workers` | 0 | DataLoader workers |
| `--no-compile` | off | Disable `torch.compile` |

---

## Variant-specific defaults

| Argument | stream-attn | dyn-graph | proto-mem |
|---|---|---|---|
| `--lr` | 3e-4 | 1e-3 | 1e-3 |
| `--batch-size` | 64 | 32 | 32 |
| `--supcon-warmup` | 20 | 20 | 8 |
| `--emb-dim` | 256 | 256 | 256 |
| `--variance-percentile` | 10.0 | 0.0 | 0.0 |
| `--dim1` | 256 | — | — |
| `--seg` | 64 | — | — |
| `--base-channels` | — | 64 | 96 |
| `--num-stages` | — | 10 | 10 |
| `--num-prototype` | — | — | 100 |
| `--lambda-proto` | — | — | 0.1 |
| `--reid-eval` default | centroid | closed-set | closed-set |

---

## Checkpoint layout

Each variant × format × task combination writes to its own directory to prevent collisions:

```
artifacts/models/unveil/<variant>/actor_holdout_split_<format>/<task>/
├── best_model.pt
├── checkpoint_epoch010.pt
├── checkpoint_epoch020.pt
├── final_<format>_<task>.pt
└── final_metrics_<format>_<task>.json
```

---

## Evaluation split structure

All variants use a three-way evaluation split:

1. **sa_seen** (seen-actors-seen-demos): 80 % of the `seen_val` actors' demos — used in training; reported for reference
2. **sa_unseen** (seen-actors-unseen-demos): held-out 20 % of `seen_val` actors' demos — used as the primary validation signal during training
3. **unseen** (unseen-actors): the `test_manifest` actors, completely held out — final reported result

The `pure_train` actors from `train_manifest.csv` are combined with the 80 % portion of `seen_val` to form the full training set.

---

## Notes

- **`stream-attn`** processes data as `(B, 3, C, T)` with three-stream (position / velocity / acceleration) input fused internally via learned adjacency.  No external model library is required.
- **`dyn-graph`** and **`proto-mem`** reshape input to `(B, 1, T, V, C_in)`: for G1, `V=35, C_in=3`; for BVH, `V=24, C_in=9` (3 rotation channels × 3 streams per joint).  These variants require all 72 BVH channels (`--variance-percentile 0.0` is enforced automatically).
- The **BONES-SEED skeleton layouts** (`bones_seed_g1`, `bones_seed_bvh`) are already registered in `DS-GCN/pyskl/utils/graph.py`; no patching is required for `dyn-graph`.  For `proto-mem`, the graph utility is patched at module load time.
- All three variants return `(logits, z, aux)` from `UNVEIL.forward`; `aux` is `None` for `stream-attn` and `dyn-graph`, and contains the reconstructed graph tensor for `proto-mem`.
